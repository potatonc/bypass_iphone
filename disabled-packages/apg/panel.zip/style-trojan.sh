#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

function lane() {
  echo -e "${BlueCyan} ————————————————————————————————————————${Suffix}"
}

function LOGO() {
  clear
	echo -e ""
	lane
	echo -e "${ungu}             Potato Tunneling            "
	lane
	echo -e ""
}

function exp_json() {
  echo -e "${yellow}         Expired  :  ${exp}"
}

function trojan_json() {
  echo -e "${ungu}                  TROJAN                 ${Suffix}"
}

function port_json() {
echo -e ""
echo -e " TROJAN"
echo -e ""
echo -e " Remarks     : ${user}"
echo -e " CITY        : $CITY"
echo -e " ISP         : $ISP"
echo -e " Host/IP     : ${domain}"
echo -e " Port        : ${trojanws}"
echo -e " Key         : ${uuid}"
echo -e " Network     : ws, grpc"
echo -e " Path        : /trojan"
echo -e " serviceName : trojan"
echo -e ""
}

function portls_json() {
echo -e ""
echo -e " TROJAN"
echo -e ""
echo -e " Remarks     : ${user}"
echo -e " CITY        : $CITY"
echo -e " ISP         : $ISP"
echo -e " Host/IP     : ${domain}"
echo -e " Port        : ${trojanws}"
echo -e " Key         : ${uuid}"
echo -e " Network     : ws"
echo -e " Path        : /trojan"
echo -e ""
}

function portgrpc_json() {
echo -e ""
echo -e " TROJAN"
echo -e ""
echo -e " Remarks     : ${user}"
echo -e " CITY        : $CITY"
echo -e " ISP         : $ISP"
echo -e " Host/IP     : ${domain}"
echo -e " Port        : ${trojanws}"
echo -e " Key         : ${uuid}"
echo -e " Network     : grpc"
echo -e " serviceName : trojan"
echo -e ""
}

function link_json() {
echo -e " Link WS     : ${trojanlink}"
lane
echo -e " Link GRPC   : ${trojanlink1}"
}

function linktls_json() {
echo -e " Link WS     : ${trojanlink}"
}

function linkgrpc_json() {
echo -e " Link GRPC   : ${trojanlink1}"
}

function all() {
LOGO
trojan_json
lane
port_json
lane
link_json
lane
exp_json
lane
}

function tls() {
LOGO
trojan_json
lane
portls_json
lane
linktls_json
lane
exp_json
lane
}

function grpc() {
LOGO
trojan_json
lane
portgrpc_json
lane
linkgrpc_json
lane
exp_json
lane
}

function responseJsonWS() {
cat > "/etc/xray/${user}-trojan-panel.json" <<-END
{
  "status": "success",
  "hostname": "${domain}",
  "ISP": "${ISP}",
  "CITY": "${CITY}",
  "username": "${user}",
  "expired": "${exp}",
  "uuid": "${uuid}",
  "port": {
    "tls": "${trojanws}"
  },
  "path": {
    "stn": "/trojan",
    "multi": "/yourbug/trojan"
  },
  "link": {
    "tls": "${trojanlink}"
  }
}
END
cat "/etc/xray/${user}-trojan-panel.json"
}

function responseJsonGRPC() {
cat > "/etc/xray/${user}-trojan-panel.json" <<-END
{
  "status": "success",
  "hostname": "${domain}",
  "ISP": "${ISP}",
  "CITY": "${CITY}",
  "username": "${user}",
  "expired": "${exp}",
  "uuid": "${uuid}",
  "port": {
    "tls": "${trojanws}"
  },
  "path": {
    "stn": "trojan"
  },
  "link": {
    "tls": "${trojanlink1}"
  }
}
END
cat "/etc/xray/${user}-trojan-panel.json"
}

if [[ ${1} == "all" ]]; then
  all
fi

if [[ ${1} == "tls" ]]; then
  tls
fi

if [[ ${1} == "grpc" ]]; then
  grpc
fi
