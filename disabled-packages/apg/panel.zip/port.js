module.exports = {
  tls: 443,
  nontls: 80,
  ssh: 80,
  drop: 80,
  ssh1: 2082,
  ssh2: 8880,
  drop1: 90,
  drop2: 69,
  xraynon: 8080,
  ovpnohp: 9088,
  sshohp: 9080,
  squid: 3128
}
