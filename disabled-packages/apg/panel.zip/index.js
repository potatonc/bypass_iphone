const express = require('express');
const bodyParser = require('body-parser');
const { exec } = require("child_process");
const util = require('util');
const GetExec = util.promisify(exec);
const app = express();
const port = 3000;

app.use(bodyParser.json());

app.use((req, res, next) => {
let validIps = ['103.253.25.15']; // Put your IP whitelist in this array

  if(validIps.includes(req.connection.remoteAddress)){
      // IP is ok, so go on
      console.log("IP ok");
      next();
  }
  else{
      // Invalid ip
      console.log("Bad IP: " + req.connection.remoteAddress);
      const err = new Error("Bad IP: " + req.connection.remoteAddress);
      next(err);
  }
})

app.use((err, req, res, next) => {
    console.log('Error handler', err);
    res.status(err.status || 500);
    res.send("Permission Denied");
});

app.get('/vps/detailport', (req, res) => {
  try {
    const portvps = require('./port');
    res.send(portvps);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/sshvpn', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.password}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/d`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/vmessws', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/a ws`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/vlessws', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/b ws`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/trojanws', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/c ws`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/vmessgrpc', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/a grpc`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/vlessgrpc', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/b grpc`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.post('/vps/trojangrpc', async (req, res) => {
  try {
    const portvps = require('./port');
    const create = await GetExec(`echo "${req.body.username}\n${req.body.limitip}\n${req.body.expired}\n" | /usr/local/bin/c grpc`);
    var toJson = JSON.parse(JSON.stringify(create.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.delete('/vps/deletevmess', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n" | /usr/local/bin/e`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.delete('/vps/deletevless', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n" | /usr/local/bin/f`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.delete('/vps/deletetrojan', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n" | /usr/local/bin/g`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.delete('/vps/deletesshvpn', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n" | /usr/local/bin/h`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.patch('/vps/renewvmess', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n${req.body.expired}\n" | /usr/local/bin/i`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.patch('/vps/renewvless', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n${req.body.expired}\n" | /usr/local/bin/j`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.patch('/vps/renewtrojan', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n${req.body.expired}\n" | /usr/local/bin/k`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.patch('/vps/renewsshvpn', async (req, res) => {
  try {
    const deleteData = await GetExec(`echo "${req.body.username}\n${req.body.expired}\n" | /usr/local/bin/l`);
    var toJson = JSON.parse(JSON.stringify(deleteData.stdout));
    res.send(toJson);
  } catch (err) {
    let myCatch = {
      status: "error"
    }
    res.send(myCatch);
  }
});

app.listen(port, () => {
  console.log(`potato api listening at http://localhost:${port}`)
});
