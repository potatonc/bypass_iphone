#!/bin/bash

red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
plain='\033[0m'
blue='\033[0;34m'
ungu='\033[0;35m'
Green="\033[32m"
Red="\033[31m"
WhiteB="\e[5;37m"
BlueCyan="\e[5;36m"
Green_background="\033[42;37m"
Red_background="\033[41;37m"
Suffix="\033[0m"

if [[ -e /usr/sbin/potatonc/slowdns/server.pub && -e /usr/sbin/potatonc/slowdns/nameserver ]]; then
pub=$(cat /usr/sbin/potatonc/slowdns/server.pub)
ns=$(cat /usr/sbin/potatonc/slowdns/nameserver)
else
pub=""
ns=""
fi

function lane() {
echo -e "${BlueCyan} ————————————————————————————————————————${Suffix}"
}

function LOGO() {
  clear
	echo -e ""
	lane
	echo -e "${ungu}             Potato Tunneling            "
	lane
	echo -e ""
}

function exp_json() {
  echo -e "${yellow}         Expired  :  ${exp}"
}

function ssh_json() {
echo -e "${ungu}               SSH/Dropbear            "
}

function openvpn_json() {
echo -e "${ungu}                 OpenVPN            "
}

function datauser_json() {
echo -e " HOST              : $IP_ADDR"
echo -e " NameServer        : ${ns}"
echo -e " Username          : $Login"
echo -e " Password          : $Pass"
echo -e " PUB Key           : ${pub}"
}

function port_json() {
echo -e " OpenSSH           : ${dhs},2222,444"
echo -e " Dropbear          : ${ddb},90,69,143"
echo -e " OpenSSH SSL       : ${sshssl}"
echo -e " Dropbear SSL      : ${dropssl}"
lane
echo -e " SSH WebSocket Direct"
echo -e "  Port : 80,7788,2082,8880"
echo -e "         8181,8282,6602"
echo -e " SSH WebSocket SSL"
echo -e "  Port : 443,8443"
lane
echo -e " SlowDNS           : 53,5300"
echo -e " OHP + SSH         : 9080"
echo -e " Proxy             : 8080"
echo -e " BadVPN UDPGW      : 7100-7600"
echo -e " OpenVPN TCP       : ${dhs},1194"
echo -e " OpenVPN SSL       : ${vpnssl1}"
echo -e " OpenVPN UDP       : ${vpnudp}"
echo -e " OpenVPN WS        : 7444"
echo -e " OpenVPN WS SSL    : 7443"
echo -e " OpenVPN DNS       : 53"
echo -e " OHP + OVPN        : ${ohp}"
}

function ovpn_json() {
echo -e " http://$IP_ADDR:81/myvpn-config.zip"
}

function ohp_json() {
if [ ! -e /usr/sbin/potatohp ]; then
echo -e " OHP Not Installed"
else
echo -e " http://$IP_ADDR:81/potato-ohp.ovpn"
echo -e " http://$IP_ADDR:81/Potato-modem.ovpn"
fi
}

function payload_json() {
echo -e " Payload SSH CDN Port 80"
echo -e ""
echo -e "${Green}GET / HTTP/1.1"
echo -e "Host: [host_port]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload SSH TLS/WSS Port 443"
echo -e ""
echo -e "${Green}GET wss://BUG/ HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: Websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload SSH WS Non TLS Port 7788"
echo -e " Path - /whatever"
echo -e ""
echo -e "${Green}GET wss://BUG/worryfree HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua]"
echo -e "Upgrade: Websocket[crlf][crlf]${Suffix}"
lane
echo -e " Payload OHP + SSH Port 9080"
echo -e " Path - /whatever"
echo -e ""
echo -e "${Green}GET https://BUG HTTP/1.1"
echo -e "Host: [host]"
echo -e "User-Agent: [ua][crlf][crlf]${Suffix}"
}

function stdoutIn() {
LOGO
ssh_json
lane
datauser_json
lane
port_json
lane
payload_json
lane
openvpn_json
lane
ovpn_json
ohp_json
lane
exp_json
lane
}

function sshJson() {
cat > "/etc/xray/${Login}-ssh-panel.json" <<-END
{
  "status": "success",
  "hostname": "${IP_ADDR}",
  "ISP": "${ISP}",
  "CITY": "${CITY}",
  "username": "${Login}",
  "servername": "${ns}",
  "pubkey": "${pub}",
  "password": "${Pass}",
  "exp": "${exp2}",
  "port": {
    "tls": "${sshssl}",
    "none": "${dhs}",
    "drop1": 90,
    "drop2": 69,
    "ssh1": 444,
    "ovpntcp": 1194,
    "ovpnudp": 25000,
    "slowdns": 53,
    "slowdns1": 5300,
    "sshohp": 9080,
    "ovpnohp": 9088,
    "squid": 3128
  },
  "payloadws": {
    "payloadcdn": "GET / HTTP/1.1
Host: [host_port]
User-Agent: [ua]
Upgrade: websocket[crlf][crlf]",
    "payloadwithpath": "GET /worryfree/ssh HTTP/1.1
Host: BUG
User-Agent: [ua]
Upgrade: websocket[crlf][crlf]"
  }
}
END
cat "/etc/xray/${Login}-ssh-panel.json"
}
